// 📁 service/PillService.java
package com.example.med_classification.service;

import com.example.med_classification.model.dto.request.PillDetectionRequestDto;
import com.example.med_classification.model.dto.request.PillInfoRequestDto;
import com.example.med_classification.model.dto.request.PillLookupRequestDto;
import com.example.med_classification.model.dto.response.PillLookupResponseDto;
import com.example.med_classification.model.entity.Drug;
import com.example.med_classification.repository.DrugRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.text.similarity.LevenshteinDistance;

@Service
@RequiredArgsConstructor
public class PillService {

    public List<Drug> findByPrintsWithFallback(PillLookupRequestDto dto) {
        String front = dto.getPrintFront();
        String back = dto.getPrintBack();

        List<Drug> allDrugs = drugRepository.findAll();

        // 1. printFront + printBack 완전 일치
        for (Drug drug : allDrugs) {
            if (front != null && back != null &&
                    drug.getPrintFront().equalsIgnoreCase(front) &&
                    drug.getPrintBack().equalsIgnoreCase(back)) {
                return List.of(drug);
            }
        }

        // 2. printFront 또는 printBack 하나만 일치
        for (Drug drug : allDrugs) {
            if ((front != null && drug.getPrintFront().equalsIgnoreCase(front)) ||
                    (back != null && drug.getPrintBack().equalsIgnoreCase(back))) {
                return List.of(drug);
            }
        }

        // 3. 모두 불일치 → 유사도 측정
        LevenshteinDistance distance = new LevenshteinDistance();

        return allDrugs.stream()
                .sorted(Comparator.comparingInt(d ->
                        distance.apply(d.getPrintFront(), front != null ? front : "") +
                                distance.apply(d.getPrintBack(), back != null ? back : "")
                ))
                .limit(4)
                .collect(Collectors.toList());
    }

    private final DrugRepository drugRepository;

    public PillLookupResponseDto findBestMatch(PillDetectionRequestDto request) {
        String front = request.getFront();
        String back = request.getBack();
        String label = request.getLabel();

        // ✅ class → color, shape 분리
        String clazz = dto.getClazz();  // getClass는 예약어이므로 getClazz로 가정
        if (clazz == null || !clazz.contains("_")) {
            throw new RuntimeException("class 형식이 '색상_모양'이어야 합니다. 받은 값: " + clazz);
        }
        String[] parts = clazz.split("_");
        String color = parts[0];
        String shape = parts[1];


        // ✅ color, shape 일치하는 약들 필터링
        List<Drug> matchingDrugs = drugRepository.findByColorAndShape(color, shape);

        if (matchingDrugs.isEmpty()) {
            throw new RuntimeException("해당 color 및 shape에 해당하는 약을 찾을 수 없습니다.");
        }

        // 1. front & back 모두 일치
        Optional<Drug> exact = matchingDrugs.stream()
                .filter(d -> Objects.equals(d.getPrintFront(), front) && Objects.equals(d.getPrintBack(), back))
                .findFirst();
        if (exact.isPresent()) return PillLookupResponseDto.from(exact.get(), label);

        // 2. 하나만 일치
        Optional<Drug> partial = matchingDrugs.stream()
                .filter(d -> Objects.equals(d.getPrintFront(), front) || Objects.equals(d.getPrintBack(), back))
                .findFirst();
        if (partial.isPresent()) return PillLookupResponseDto.from(partial.get(), label);

        // 3. 유사도 측정
        LevenshteinDistance distance = new LevenshteinDistance();
        Drug bestMatch = null;
        int bestScore = Integer.MAX_VALUE;

        for (Drug drug : matchingDrugs) {
            int frontScore = front != null ? distance.apply(front, Optional.ofNullable(drug.getPrintFront()).orElse("")) : 100;
            int backScore = back != null ? distance.apply(back, Optional.ofNullable(drug.getPrintBack()).orElse("")) : 100;
            int total = frontScore + backScore;

            if (total < bestScore) {
                bestScore = total;
                bestMatch = drug;
            }
        }

        if (bestMatch == null) {
            throw new RuntimeException("일치하는 알약을 찾을 수 없습니다.");
        }

        return PillLookupResponseDto.from(bestMatch, label);
    }


//    public PillLookupResponseDto findPillByDetectionResult(PillLookupRequestDto dto) {
//        List<Drug> matches = drugRepository.findByNameContainingOrImprintFrontContaining(
//                dto.getDetectedText(), dto.getDetectedText()
//        );
//
//
//        if (matches.isEmpty()) {
//            throw new RuntimeException("약을 찾을 수 없습니다.");
//        }
//
//        return new PillLookupResponseDto(matches.get(0));
//    }
public List<Drug> findPillByDetection(PillLookupRequestDto dto) {
    List<Drug> drugs = drugRepository.findByDetection(
            dto.getPrintFront(),
            dto.getPrintBack(),
            dto.getColor(),
            dto.getShape()
    );

    if (drugs.isEmpty()) {
        throw new RuntimeException("일치하는 약을 찾을 수 없습니다.");
    }

    return drugs;
}

    public PillLookupResponseDto findById(Integer id) {
        Drug drug = drugRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("약을 찾을 수 없습니다."));
        return new PillLookupResponseDto(drug);
    }


//    public List<PillLookupResponseDto> findByIds(List<String> ids) {
//        List<Drug> drugs = drugRepository.findAllById(ids);
//        return drugs.stream()
//                .map(PillLookupResponseDto::new)
//                .toList();
//    }

    public List<PillLookupResponseDto> findByInfo(PillInfoRequestDto dto) {
        List<Drug> results = drugRepository.findByMultipleAttributes(
                dto.getColor(),
                dto.getPrint_front(),
                dto.getPrint_back(),
                dto.getShape(),
                dto.getCompany()
        );

        if (results.isEmpty()) {
            throw new RuntimeException("알약 정보를 찾을 수 없습니다.");
        }

        return results.stream()
                .map(PillLookupResponseDto::new)
                .collect(Collectors.toList());
    }





}
